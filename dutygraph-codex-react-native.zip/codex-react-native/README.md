# DutyGraph React Native build package (for Codex)

This folder is a complete, stand-alone brief for an AI coding agent (Codex) to build the React Native version of DutyGraph's **information-gathering tool** (spoken interview cards, Task Card checks) and **meeting tool** (Meeting OS: POWER builder, Meeting Gate, Pulse, live Capture / Copilot / Facilitator, closing ritual, results), with **voice-to-voice on top of the existing cards**. It contains no secrets.

## How to hand it to Codex (for Matt)

1. Unzip `dutygraph-codex-react-native.zip` into an empty folder (or point Codex at this folder).
2. Create an empty Git repo for it, for example `dutygraph-mobile`, and open it in the Codex app with this folder copied in.
3. Paste the whole of [CODEX-PROMPT.md](CODEX-PROMPT.md) as the first message. It tells Codex to read the PRD and the build plan and to run all phases without stopping.
4. Optional: give the Codex environment `OPENAI_API_KEY` only if you want the one manual rehearsal at the end (docs/09 §5). Every test runs without it.
5. In the morning, read `PROGRESS.md` at the top of the new repo first. It lists what was built, check results, anything blocked, and five open questions for you.

Codex does **not** change the DutyGraph web app or its database. It builds a separate repo with the app, a dev server that stands in for the endpoints DutyGraph does not have yet, and a porting guide for Jesse.

## What is in here

| Path | What |
| --- | --- |
| [PRD.md](PRD.md) | Product requirements: users, scope, voice layer, design, Meeting OS, data, backend, phases, definition of done |
| [CODEX-PROMPT.md](CODEX-PROMPT.md) | The kickoff prompt to paste into Codex |
| [docs/01-BUILD-PLAN.md](docs/01-BUILD-PLAN.md) | Phases 0 to 14 plus extra passes, with checks and what to do when blocked |
| [docs/02-ARCHITECTURE.md](docs/02-ARCHITECTURE.md) | Repo layout, app layers, state machines, data flows, offline, security |
| [docs/03-DESIGN-SYSTEM.md](docs/03-DESIGN-SYSTEM.md) | Tokens, type, card layouts, components, Matt's design rules |
| [docs/04-VOICE.md](docs/04-VOICE.md) | Voice-to-voice on the cards: spoken questions, speech in, nudges, barge-in, flags |
| [docs/05-MEETING-OS.md](docs/05-MEETING-OS.md) | Carson Tate's POWER framework, meeting types, roles, gate, lifecycle, facilitator, closing ritual |
| [docs/06-INFORMATION-GATHERING.md](docs/06-INFORMATION-GATHERING.md) | Interview requests, card deck, review, Task Card checks, kickoff capture |
| [docs/07-BACKEND-AND-API.md](docs/07-BACKEND-AND-API.md) | How to connect to DutyGraph: the real mobile API, proposed endpoints, dev server, env var names |
| [docs/08-DATA-MODEL.md](docs/08-DATA-MODEL.md) | Built types and new types |
| [docs/09-TESTING-AND-QA.md](docs/09-TESTING-AND-QA.md) | Commands, test scope, E2E flows A to I, device checklist |
| [docs/10-RULES-AND-GUARDRAILS.md](docs/10-RULES-AND-GUARDRAILS.md) | Privacy, consent, security, claim discipline |
| [docs/11-DECISIONS-AND-DEFAULTS.md](docs/11-DECISIONS-AND-DEFAULTS.md) | 30 defaults so Codex never needs to ask, and the open questions for Matt |
| `seed/` | A working copy of today's Expo Companion app plus the shared deck logic, contracts, prompt pack and tests (checked: 312 app tests and 48 shared tests pass) |
| `reference/` | Source docs, the HTML design prototype and screenshots, and web/server code to read (see [reference/README.md](reference/README.md)) |

## Status words used in these docs

- **Built**: exists and is tested in DutyGraph today (October 27, 2026).
- **Proposed**: designed, not built in DutyGraph. Codex builds it in the new repo against the dev server.
- Nothing in this package says a proposed part works on a real phone or with a real provider. Codex records that in `PROGRESS.md` only after it is run.
